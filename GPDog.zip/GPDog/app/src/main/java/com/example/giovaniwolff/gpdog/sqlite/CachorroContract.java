package com.example.giovaniwolff.gpdog.sqlite;

import android.provider.BaseColumns;

public class CachorroContract implements BaseColumns {

    public static final String TABLE_NAME = "cachorro";
    public static final String COLUMN_NAME_NOME = "nome";
    public static final String COLUMN_NAME_RACA = "raca";
    public static final String COLUMN_NAME_PELAGEM = "pelagem";
    public static final String COLUMN_NAME_IDADEAPROXIMADA = "idadeAproximada";
    public static final String COLUMN_NAME_CASTRADO = "castrado";
    public static final String COLUMN_NAME_BAIRRO = "bairro";

    public static final String SQL_CREATE_CACHORROS =
            "CREATE TABLE " + TABLE_NAME + " ("+
                    _ID + " INTEGER PRIMARY KEY, "+
                    COLUMN_NAME_NOME + " TEXT, " +
                    COLUMN_NAME_RACA + " TEXT, " +
                    COLUMN_NAME_PELAGEM + " TEXT, " +
                    COLUMN_NAME_CASTRADO + " TEXT, " +
                    COLUMN_NAME_BAIRRO + " TEXT, " +
                    COLUMN_NAME_IDADEAPROXIMADA+ " TEXT)";

    public static final String SQL_DELETE_CACHORROS=
            "DROP TABLE IF EXISTS " + TABLE_NAME;

}
