package com.example.giovaniwolff.gpdog.sqlite;

import java.io.Serializable;

public class Cachorro implements Serializable {

    private int _id;
    private String nome;
    private String raca;
    private String idadeAproximada;
    private String pelagem;
    private String castrado;
    private String bairro;

    @Override
    public String toString(){
        return this.nome+"\n"+this.raca+"\n"+this.bairro;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public String getIdadeAproximada() {
        return idadeAproximada;
    }

    public void setIdadeAproximada(String idadeAproximada) {
        this.idadeAproximada = idadeAproximada;
    }

    public String getPelagem() {
        return pelagem;
    }

    public void setPelagem(String pelagem) {
        this.pelagem = pelagem;
    }

    public String getCastrado() {
        return castrado;
    }

    public void setCastrado(String castrado) {
        this.castrado = castrado;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }
}
