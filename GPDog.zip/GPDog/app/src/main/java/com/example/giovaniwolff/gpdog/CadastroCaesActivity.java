package com.example.giovaniwolff.gpdog;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.giovaniwolff.gpdog.sqlite.Cachorro;
import com.example.giovaniwolff.gpdog.sqlite.CachorroReaderDbHelper;

import java.io.BufferedReader;

public class CadastroCaesActivity extends AppCompatActivity {


    private CachorroReaderDbHelper cachorroReaderDbHelper = new CachorroReaderDbHelper(this);
    private Button btnCadastrar;
    private EditText edtNome, edtRaca, edtPelagem, edtIdadeAprox, edtBairro;
    private Spinner spnCastrado;
    private boolean salvar=true;
    private Cachorro cachorro = new Cachorro();
    int id2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_caes);

        btnCadastrar = findViewById(R.id.btnCadastrar);

        edtBairro = findViewById(R.id.edtBairro);
        edtIdadeAprox = findViewById(R.id.edtIdadeAproximada);
        edtNome = findViewById(R.id.edtNome);
        edtPelagem = findViewById(R.id.edtPelagem);
        edtRaca = findViewById(R.id.edtRaca);

        spnCastrado = findViewById(R.id.spnCastrado);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.castrado, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnCastrado.setAdapter(adapter);

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvar();
            }
        });

        Intent intent = getIntent();
        if(intent.hasExtra("cachorro")){

            salvar=false;

            cachorro = (Cachorro) intent.getSerializableExtra("cachorro");
            edtNome.setText(cachorro.getNome());
            edtBairro.setText(cachorro.getBairro());
            edtIdadeAprox.setText(cachorro.getIdadeAproximada());
            edtRaca.setText(cachorro.getRaca());
            edtPelagem.setText(cachorro.getPelagem());
            if(cachorro.getCastrado().equalsIgnoreCase("SIM")){
                spnCastrado.setSelection(0);
            }else {
                spnCastrado.setSelection(1);
            }


        }
    }

    public void salvar(){

        cachorro.setRaca(edtRaca.getText().toString());
        cachorro.setPelagem(edtPelagem.getText().toString());
        cachorro.setNome(edtNome.getText().toString());
        cachorro.setIdadeAproximada(edtIdadeAprox.getText().toString());
        cachorro.setBairro(edtBairro.getText().toString());
        cachorro.setCastrado((String) spnCastrado.getSelectedItem());

        try {
            if (salvar){
                cachorroReaderDbHelper.create(cachorro);
                Toast.makeText(this, "Registro Salvo.", Toast.LENGTH_LONG).show();
            }else{
                cachorroReaderDbHelper.update(cachorro);
                Toast.makeText(this, "id: "+cachorro.get_id(), Toast.LENGTH_LONG).show();
                Toast.makeText(this, "nome: "+cachorro.getNome(), Toast.LENGTH_LONG).show();
                Toast.makeText(this, "Registro Atualizado.", Toast.LENGTH_LONG).show();
            }

            Intent intent = new Intent(this, ListagemCaesActivity.class);
            startActivity(intent);
            finish();

        } catch (Exception e){
            e.printStackTrace();
        }
    }

}
