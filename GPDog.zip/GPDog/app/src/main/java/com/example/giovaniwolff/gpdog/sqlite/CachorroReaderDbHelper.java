package com.example.giovaniwolff.gpdog.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class CachorroReaderDbHelper extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "GPDog.db";

    public CachorroReaderDbHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CachorroContract.SQL_CREATE_CACHORROS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(CachorroContract.SQL_DELETE_CACHORROS);
        sqLiteDatabase.execSQL(CachorroContract.SQL_CREATE_CACHORROS);
    }

    //CRUD
    public void create (Cachorro cachorro){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(CachorroContract.COLUMN_NAME_NOME, cachorro.getNome());
        values.put(CachorroContract.COLUMN_NAME_RACA, cachorro.getRaca());
        values.put(CachorroContract.COLUMN_NAME_BAIRRO, cachorro.getBairro());
        values.put(CachorroContract.COLUMN_NAME_CASTRADO, cachorro.getCastrado());
        values.put(CachorroContract.COLUMN_NAME_IDADEAPROXIMADA, cachorro.getIdadeAproximada());
        values.put(CachorroContract.COLUMN_NAME_PELAGEM, cachorro.getPelagem());

        long newRowId = db.insert(CachorroContract.TABLE_NAME,null,values);

        db.close();
    }

    public void delete(int id){
        SQLiteDatabase db = getWritableDatabase();
        String selection = CachorroContract._ID + "= ?";
        String[] selectionArgs = { "" +id };
        int deletedRows = db.delete(CachorroContract.TABLE_NAME, selection, selectionArgs);

        db.close();
    }

    public int update(Cachorro cachorro){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(CachorroContract.COLUMN_NAME_NOME, cachorro.getNome());
        values.put(CachorroContract.COLUMN_NAME_RACA, cachorro.getRaca());
        values.put(CachorroContract.COLUMN_NAME_BAIRRO, cachorro.getBairro());
        values.put(CachorroContract.COLUMN_NAME_CASTRADO, cachorro.getCastrado());
        values.put(CachorroContract.COLUMN_NAME_IDADEAPROXIMADA, cachorro.getIdadeAproximada());
        values.put(CachorroContract.COLUMN_NAME_PELAGEM, cachorro.getPelagem());

        String selection = CachorroContract._ID + " = ?";
        String[] selectionArgs = {""+ cachorro.get_id()};

        int count = db.update(
                CachorroContract.TABLE_NAME,
                values,
                selection,
                selectionArgs);
        return count;
    }

    public List<Cachorro> read(){

        SQLiteDatabase db = getReadableDatabase();

        String[] projection = {
                CachorroContract._ID,
                CachorroContract.COLUMN_NAME_NOME,
                CachorroContract.COLUMN_NAME_CASTRADO,
                CachorroContract.COLUMN_NAME_IDADEAPROXIMADA,
                CachorroContract.COLUMN_NAME_RACA,
                CachorroContract.COLUMN_NAME_BAIRRO,
                CachorroContract.COLUMN_NAME_PELAGEM
        };

        String sortOrder =
                CachorroContract.COLUMN_NAME_NOME + " DESC";

        Cursor cursor = db.query(
                CachorroContract.TABLE_NAME,   // The table to query
                projection,             // The array of columns to return (pass null to get all)
                null,              // The columns for the WHERE clause
                null,          // The values for the WHERE clause
                null,                   // don't group the rows
                null,                   // don't filter by row groups
                sortOrder               // The sort order
        );
        List<Cachorro> cachorros = new ArrayList<>();
        while(cursor.moveToNext()){
            Cachorro cachorro = new Cachorro();
            cachorro.set_id(cursor.getInt(cursor.getColumnIndex(CachorroContract._ID)));
            cachorro.setNome(cursor.getString(cursor.getColumnIndex(CachorroContract.COLUMN_NAME_NOME)));
            cachorro.setBairro(cursor.getString(cursor.getColumnIndex(CachorroContract.COLUMN_NAME_BAIRRO)));
            cachorro.setCastrado(cursor.getString(cursor.getColumnIndex(CachorroContract.COLUMN_NAME_CASTRADO)));
            cachorro.setIdadeAproximada(cursor.getString(cursor.getColumnIndex(CachorroContract.COLUMN_NAME_IDADEAPROXIMADA)));
            cachorro.setPelagem(cursor.getString(cursor.getColumnIndex(CachorroContract.COLUMN_NAME_PELAGEM)));
            cachorro.setRaca(cursor.getString(cursor.getColumnIndex(CachorroContract.COLUMN_NAME_RACA)));

            cachorros.add(cachorro);
        }
        cursor.close();
        db.close();
        return cachorros;
    }

}
