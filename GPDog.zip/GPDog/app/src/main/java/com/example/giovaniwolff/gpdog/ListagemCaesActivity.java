package com.example.giovaniwolff.gpdog;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.giovaniwolff.gpdog.sqlite.Cachorro;
import com.example.giovaniwolff.gpdog.sqlite.CachorroReaderDbHelper;

import java.util.ArrayList;
import java.util.List;

public class ListagemCaesActivity extends AppCompatActivity {

    private CachorroReaderDbHelper cachorroReaderDbHelper = new CachorroReaderDbHelper(this);
    private ListView lvCaes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listagem_caes);
        lvCaes = findViewById(R.id.lvCaes);

        lvCaes.setOnItemClickListener(new ListView.OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Cachorro cachorro = (Cachorro) lvCaes.getItemAtPosition(i);
                Intent intent = new Intent(ListagemCaesActivity.this, CadastroCaesActivity.class);
                intent.putExtra("cachorro", cachorro);
                startActivity(intent);
                finish();
            }
        });

        lvCaes.setOnItemLongClickListener(new ListView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                final Context ctx = view.getContext();
                final Cachorro cachorro = (Cachorro) lvCaes.getItemAtPosition(position);

                AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                builder.setTitle("Confirmação")
                        .setMessage("Tem certeza que deseja excluir este registro?")
                        .setPositiveButton("Excluir", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                new CachorroReaderDbHelper(getBaseContext()).delete(cachorro.get_id());
                                Toast.makeText(ctx, "id: "+cachorro.get_id(), Toast.LENGTH_LONG).show();
                                Toast.makeText(ctx, "Registro excluído com sucesso!", Toast.LENGTH_LONG).show();
                            }
                        })
                        .setNegativeButton("Cancelar",null)
                        .create()
                        .show();
                return true;

            }
        });

        listar();
    }

    private void listar() {
        try {
            List<Cachorro> cachorros = cachorroReaderDbHelper.read();

            ArrayAdapter<Cachorro> adapter =
                    new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, cachorros);

            lvCaes.setAdapter(adapter);
        } catch (Exception e){
            Toast.makeText(this,"Falha", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.itemNovo:
                Intent intent = new Intent(ListagemCaesActivity.this, CadastroCaesActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
